import { combineReducers } from 'redux';
import { artwalks } from './artwalks';

export default combineReducers({
  artwalks
})
